/* ═══════════════════════════════════════════════
   LOGITRACK — app.js
   Modules: Dashboard, Cubicaje, Enturnamiento, Rutas
   Backend: Supabase (optional) + localStorage fallback
═══════════════════════════════════════════════ */

'use strict';

// ═══════════════════════════════════════════════
// GLOBAL STATE
// ═══════════════════════════════════════════════
const STATE = {
  products: [],          // cubicaje products list
  citas: [],             // citas/appointments
  routes: [],            // saved routes
  supabase: null,        // supabase client
  useSupabase: false,    // flag
  map: null,             // mapbox map instance
  mapView: 'map',        // 'map' | 'list'
  citaFilter: 'all',
};

// Container specs (m³ and max kg)
const CONTAINERS = {
  '20ft':  { label: 'Contenedor 20 pies', vol: 33.2,  maxkg: 28000 },
  '40ft':  { label: 'Contenedor 40 pies', vol: 67.7,  maxkg: 26500 },
  'camion':{ label: 'Camión / Mula',      vol: 90.0,  maxkg: 35000 },
  'furgon':{ label: 'Furgón pequeño',     vol: 15.0,  maxkg: 3500  },
};

// ═══════════════════════════════════════════════
// INIT
// ═══════════════════════════════════════════════
document.addEventListener('DOMContentLoaded', () => {
  setDate();
  loadDemoData();
  renderDashboard();
  renderCitas();
  buildWeekStrip();
  // Show modal on load (Supabase config)
  document.getElementById('supabaseModal').style.display = 'flex';
});

function setDate() {
  const d = new Date();
  document.getElementById('currentDate').textContent =
    d.toLocaleDateString('es-CO', { weekday: 'short', day: 'numeric', month: 'short', year: 'numeric' });
}

// ═══════════════════════════════════════════════
// DEMO DATA
// ═══════════════════════════════════════════════
function loadDemoData() {
  const today = new Date();
  const fmt = (d) => d.toISOString().split('T')[0];
  const addDays = (n) => { const d = new Date(); d.setDate(d.getDate() + n); return d; };

  STATE.citas = [
    { id: 1, empresa: 'Almacenes Éxito S.A.',       tipo: 'carga',    fecha: fmt(today),         hora: '08:00', muelle: 'Muelle 1', duracion: 60,  estado: 'confirmado', notas: 'Traer orden de compra #4821' },
    { id: 2, empresa: 'Supermercados Olímpica',      tipo: 'descarga', fecha: fmt(today),         hora: '10:30', muelle: 'Muelle 2', duracion: 90,  estado: 'pendiente',  notas: '' },
    { id: 3, empresa: 'Jumbo Colombia',              tipo: 'mixto',    fecha: fmt(today),         hora: '14:00', muelle: 'Muelle 1', duracion: 120, estado: 'pendiente',  notas: 'Coordinar con jefe de patio' },
    { id: 4, empresa: 'D1 Logística',                tipo: 'carga',    fecha: fmt(today),         hora: '16:30', muelle: 'Muelle 3', duracion: 60,  estado: 'completado', notas: '' },
    { id: 5, empresa: 'Carulla S.A.',                tipo: 'descarga', fecha: fmt(addDays(1)),    hora: '07:00', muelle: 'Muelle 2', duracion: 90,  estado: 'confirmado', notas: '' },
    { id: 6, empresa: 'Makro Colombia',              tipo: 'carga',    fecha: fmt(addDays(1)),    hora: '11:00', muelle: 'Muelle 4', duracion: 60,  estado: 'pendiente',  notas: 'Productos refrigerados' },
    { id: 7, empresa: 'Sodimac S.A.S.',              tipo: 'mixto',    fecha: fmt(addDays(2)),    hora: '09:30', muelle: 'Muelle 1', duracion: 180, estado: 'pendiente',  notas: '' },
    { id: 8, empresa: 'Ferretería Construmax',       tipo: 'carga',    fecha: fmt(addDays(3)),    hora: '08:00', muelle: 'Muelle 2', duracion: 90,  estado: 'pendiente',  notas: '' },
  ];

  STATE.products = [
    { id: 1, name: 'Caja estándar A',     l: 60,  w: 40,  h: 40,  weight: 15, qty: 20 },
    { id: 2, name: 'Pallet electrónico',  l: 120, w: 100, h: 80,  weight: 80, qty: 5  },
    { id: 3, name: 'Caja pequeña B',      l: 30,  w: 20,  h: 20,  weight: 5,  qty: 50 },
  ];
}

// ═══════════════════════════════════════════════
// MODULE NAVIGATION
// ═══════════════════════════════════════════════
function showModule(name) {
  document.querySelectorAll('.module').forEach(m => m.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));

  document.getElementById(`mod-${name}`).classList.add('active');
  document.querySelector(`[data-module="${name}"]`).classList.add('active');

  const titles = {
    dashboard: ['Dashboard',       'Vista general de operaciones'],
    cubicaje:  ['Cubicaje',        'Cálculo de carga y optimización de espacio'],
    citas:     ['Enturnamiento',   'Agenda de citas de carga y descarga'],
    rutas:     ['Enrutamiento',    'Planificación y optimización de rutas'],
  };

  document.getElementById('pageTitle').textContent    = titles[name][0];
  document.getElementById('pageSubtitle').textContent = titles[name][1];

  if (name === 'cubicaje') renderProductsTable();
  if (name === 'citas')    { buildWeekStrip(); renderCitas(); }
  if (name === 'rutas')    initMap();
}

// ═══════════════════════════════════════════════
// DASHBOARD
// ═══════════════════════════════════════════════
function renderDashboard() {
  renderCitasMini();
  renderContainerBars();
  renderActivityChart();
}

function renderCitasMini() {
  const today = new Date().toISOString().split('T')[0];
  const todayCitas = STATE.citas.filter(c => c.fecha === today).slice(0, 4);
  const el = document.getElementById('citasMini');
  el.innerHTML = todayCitas.map(c => `
    <div class="cita-mini-item">
      <span class="cita-time">${c.hora}</span>
      <div class="cita-detail">
        <div class="cita-empresa">${c.empresa}</div>
        <div class="cita-muelle">${c.muelle} · ${c.tipo}</div>
      </div>
      <span class="status-badge status-${c.estado}">${capitalize(c.estado)}</span>
    </div>
  `).join('') || '<div class="empty-state">No hay citas hoy</div>';
}

function renderContainerBars() {
  const data = [
    { name: 'Contenedor A — 20ft', pct: 73, color: '#3b82f6' },
    { name: 'Contenedor B — 40ft', pct: 45, color: '#10b981' },
    { name: 'Camión 001',          pct: 91, color: '#f59e0b' },
    { name: 'Furgón F-12',         pct: 28, color: '#8b5cf6' },
  ];
  document.getElementById('containerBars').innerHTML = data.map(d => `
    <div class="cbar-item">
      <div class="cbar-header">
        <span class="cbar-label">${d.name}</span>
        <span class="cbar-pct">${d.pct}%</span>
      </div>
      <div class="cbar-track">
        <div class="cbar-fill" style="width:${d.pct}%;background:${d.color}"></div>
      </div>
    </div>
  `).join('');
}

function renderActivityChart() {
  const days = ['Lun', 'Mar', 'Mié', 'Jue', 'Vie', 'Sáb', 'Dom'];
  const vals = [6, 9, 7, 12, 8, 4, 2];
  const max  = Math.max(...vals);
  const colors = ['#3b82f6','#3b82f6','#3b82f6','#60a5fa','#3b82f6','#8b5cf6','#555d72'];
  document.getElementById('activityChart').innerHTML = days.map((d, i) => `
    <div class="act-bar-wrap">
      <div class="act-bar" style="height:${(vals[i]/max)*60}px;background:${colors[i]}"></div>
      <span class="act-label">${d}</span>
    </div>
  `).join('');
}

// ═══════════════════════════════════════════════
// CUBICAJE MODULE
// ═══════════════════════════════════════════════
function addProduct(e) {
  e.preventDefault();
  const name   = document.getElementById('prodName').value.trim();
  const l      = parseFloat(document.getElementById('prodL').value);
  const w      = parseFloat(document.getElementById('prodW').value);
  const h      = parseFloat(document.getElementById('prodH').value);
  const weight = parseFloat(document.getElementById('prodWeight').value);
  const qty    = parseInt(document.getElementById('prodQty').value);

  const prod = { id: Date.now(), name, l, w, h, weight, qty };
  STATE.products.push(prod);

  renderProductsTable();
  updateContainerViz();
  saveToStorage();
  toast(`✔ "${name}" agregado`, 'success');
  document.getElementById('cubicajeForm').reset();
}

function removeProduct(id) {
  STATE.products = STATE.products.filter(p => p.id !== id);
  renderProductsTable();
  updateContainerViz();
  saveToStorage();
}

function renderProductsTable() {
  const body = document.getElementById('productsBody');
  if (!STATE.products.length) {
    body.innerHTML = '<div class="empty-state">Agrega productos para calcular la carga</div>';
    document.getElementById('summaryBar').style.display = 'none';
    updateContainerViz(true);
    return;
  }

  body.innerHTML = STATE.products.map(p => {
    const volUnit = (p.l * p.w * p.h / 1e6).toFixed(4);
    const volTot  = (volUnit * p.qty).toFixed(3);
    return `
      <div class="product-row">
        <span class="prod-name">${p.name}</span>
        <span class="prod-dims">${p.l}×${p.w}×${p.h} cm</span>
        <span>${volUnit} m³</span>
        <span>${p.qty}</span>
        <span>${volTot} m³</span>
        <button class="btn-remove-prod" onclick="removeProduct(${p.id})">×</button>
      </div>`;
  }).join('');

  document.getElementById('summaryBar').style.display = 'flex';
  updateContainerViz();
}

function updateContainerViz(empty = false) {
  const cType = document.getElementById('containerType')?.value || '20ft';
  const cont  = CONTAINERS[cType];

  if (empty || !STATE.products.length) {
    document.getElementById('containerFill').style.width = '0%';
    document.getElementById('containerLabel').textContent = '0%';
    document.getElementById('infoCapacity').textContent = `Capacidad: ${cont.vol} m³`;
    document.getElementById('infoUsed').textContent    = 'Usado: 0 m³';
    document.getElementById('infoFit').textContent     = 'Caben: —';
    document.getElementById('infoWeight').textContent  = 'Peso total: 0 kg';
    return;
  }

  let totalVol = 0, totalWeight = 0;
  STATE.products.forEach(p => {
    const volUnit = p.l * p.w * p.h / 1e6;
    totalVol    += volUnit * p.qty;
    totalWeight += p.weight * p.qty;
  });

  const pct = Math.min(100, (totalVol / cont.vol) * 100);
  const fill = document.getElementById('containerFill');
  fill.style.width = `${pct}%`;
  fill.style.background = pct > 90 ? '#ef4444' : pct > 70 ? '#f59e0b' : '#3b82f6';

  document.getElementById('containerLabel').textContent  = `${pct.toFixed(1)}%`;
  document.getElementById('infoCapacity').textContent    = `Capacidad: ${cont.vol} m³`;
  document.getElementById('infoUsed').textContent        = `Usado: ${totalVol.toFixed(2)} m³`;
  document.getElementById('infoFit').textContent         = pct > 100 ? '⚠ Excede capacidad' : `Disponible: ${(cont.vol - totalVol).toFixed(2)} m³`;
  document.getElementById('infoWeight').textContent      = `Peso total: ${totalWeight.toFixed(1)} kg`;

  // Summary bar
  document.getElementById('sumVol').textContent    = `${totalVol.toFixed(2)} m³`;
  document.getElementById('sumWeight').textContent = `${totalWeight.toFixed(1)} kg`;
  document.getElementById('sumEff').textContent    = `${pct.toFixed(1)}%`;
}

function loadExample(type) {
  const examples = {
    pallets: [
      { name: 'Pallet estándar',   l: 120, w: 100, h: 120, weight: 800, qty: 10 },
      { name: 'Pallet europeo',    l: 120, w: 80,  h: 100, weight: 600, qty: 8  },
    ],
    cajas: [
      { name: 'Caja grande',       l: 80,  w: 60,  h: 60,  weight: 30,  qty: 25 },
      { name: 'Caja mediana',      l: 50,  w: 40,  h: 40,  weight: 15,  qty: 40 },
      { name: 'Caja pequeña',      l: 30,  w: 20,  h: 20,  weight: 5,   qty: 100 },
    ],
    electrodomesticos: [
      { name: 'Lavadora',          l: 60,  w: 55,  h: 85,  weight: 70,  qty: 5  },
      { name: 'Nevera mediana',    l: 60,  w: 65,  h: 160, weight: 80,  qty: 4  },
      { name: 'Microondas',        l: 48,  w: 35,  h: 28,  weight: 12,  qty: 10 },
    ],
  };

  STATE.products = examples[type].map((p, i) => ({ ...p, id: Date.now() + i }));
  renderProductsTable();
  updateContainerViz();
  toast(`Ejemplo "${type}" cargado`, 'success');
}

function clearProducts() {
  STATE.products = [];
  renderProductsTable();
  toast('Lista limpiada', 'success');
}

function saveCubicaje() {
  saveToStorage();
  toast('✔ Cubicaje guardado', 'success');
  if (STATE.useSupabase) saveCubicajeToSupabase();
}

// ═══════════════════════════════════════════════
// ENTURNAMIENTO / CITAS MODULE
// ═══════════════════════════════════════════════
function addCita(e) {
  e.preventDefault();
  const cita = {
    id:        Date.now(),
    empresa:   document.getElementById('citaEmpresa').value.trim(),
    tipo:      document.getElementById('citaTipo').value,
    fecha:     document.getElementById('citaFecha').value,
    hora:      document.getElementById('citaHora').value,
    muelle:    document.getElementById('citaMuelle').value,
    duracion:  parseInt(document.getElementById('citaDuracion').value),
    notas:     document.getElementById('citaNotas').value.trim(),
    estado:    'pendiente',
  };

  STATE.citas.push(cita);
  renderCitas();
  buildWeekStrip();
  saveToStorage();
  toast(`✔ Cita para "${cita.empresa}" agendada`, 'success');
  document.getElementById('citaForm').reset();

  if (STATE.useSupabase) saveCitaToSupabase(cita);
}

function updateCitaStatus(id, newStatus) {
  const c = STATE.citas.find(x => x.id === id);
  if (!c) return;
  c.estado = newStatus;
  renderCitas();
  saveToStorage();
  toast(`Estado actualizado: ${capitalize(newStatus)}`, 'success');
}

function deleteCita(id) {
  STATE.citas = STATE.citas.filter(c => c.id !== id);
  renderCitas();
  buildWeekStrip();
  saveToStorage();
  toast('Cita eliminada', 'success');
}

function filterCitas(filter, btn) {
  STATE.citaFilter = filter;
  document.querySelectorAll('.filter-chips .chip').forEach(c => c.classList.remove('active'));
  btn.classList.add('active');
  renderCitas();
}

function renderCitas() {
  const list = document.getElementById('citasList');
  if (!list) return;

  let filtered = STATE.citas;
  if (STATE.citaFilter !== 'all') {
    filtered = filtered.filter(c => c.estado === STATE.citaFilter);
  }
  // Sort by fecha+hora
  filtered.sort((a, b) => `${a.fecha}${a.hora}` > `${b.fecha}${b.hora}` ? 1 : -1);

  if (!filtered.length) {
    list.innerHTML = '<div class="empty-state">No hay citas para mostrar</div>';
    return;
  }

  const tipoColors = { carga: '#10b981', descarga: '#ef4444', mixto: '#f59e0b' };
  const statusNext = { pendiente: 'confirmado', confirmado: 'completado', completado: 'pendiente' };
  const statusEmoji = { pendiente: '▷', confirmado: '✓', completado: '✔✔' };

  list.innerHTML = filtered.map(c => {
    const color = tipoColors[c.tipo] || '#3b82f6';
    return `
      <div class="cita-card">
        <div class="cita-accent-bar" style="background:${color}"></div>
        <div class="cita-content">
          <div class="cita-header-row">
            <span class="cita-empresa-name">${c.empresa}</span>
            <span class="status-badge status-${c.estado}">${capitalize(c.estado)}</span>
          </div>
          <div class="cita-meta">
            <span>📅 ${formatDate(c.fecha)}</span>
            <span>🕐 ${c.hora}</span>
            <span>🚪 ${c.muelle}</span>
            <span>⏱ ${c.duracion} min</span>
            <span>${tipoLabel(c.tipo)}</span>
          </div>
          ${c.notas ? `<div style="font-size:11px;color:var(--text-3);margin-top:4px">📝 ${c.notas}</div>` : ''}
        </div>
        <div class="cita-actions">
          <button class="btn-icon" title="Avanzar estado" onclick="updateCitaStatus(${c.id}, '${statusNext[c.estado]}')">${statusEmoji[c.estado]}</button>
          <button class="btn-icon" title="Eliminar" onclick="deleteCita(${c.id})" style="color:var(--red)">✕</button>
        </div>
      </div>`;
  }).join('');
}

function buildWeekStrip() {
  const strip = document.getElementById('weekStrip');
  if (!strip) return;
  const days = ['Dom','Lun','Mar','Mié','Jue','Vie','Sáb'];
  const today = new Date();
  const todayStr = today.toISOString().split('T')[0];

  // Get week starting from Monday
  const day = today.getDay();
  const monday = new Date(today);
  monday.setDate(today.getDate() - ((day + 6) % 7));

  let html = '';
  for (let i = 0; i < 7; i++) {
    const d = new Date(monday);
    d.setDate(monday.getDate() + i);
    const dStr = d.toISOString().split('T')[0];
    const isToday = dStr === todayStr;
    const hasCitas = STATE.citas.some(c => c.fecha === dStr);
    html += `
      <div class="day-cell ${isToday ? 'today' : ''}">
        <div class="day-name">${days[d.getDay()]}</div>
        <div class="day-num">${d.getDate()}</div>
        ${hasCitas ? '<div class="day-dot"></div>' : ''}
      </div>`;
  }
  strip.innerHTML = html;
}

// ═══════════════════════════════════════════════
// ENRUTAMIENTO MODULE
// ═══════════════════════════════════════════════
function initMap() {
  if (STATE.map) return; // already initialized

  // Mapbox token (demo/public token - replace with your own)
  mapboxgl.accessToken = 'pk.eyJ1IjoibG9naXRyYWNrLWRlbW8iLCJhIjoiY2x5ZGVtbyJ9.placeholder';

  // If mapbox token invalid, show visual fallback
  try {
    STATE.map = new mapboxgl.Map({
      container: 'routeMap',
      style: 'mapbox://styles/mapbox/dark-v11',
      center: [-74.0721, 4.7110], // Bogotá
      zoom: 5.5,
    });
    STATE.map.addControl(new mapboxgl.NavigationControl(), 'top-right');
    document.getElementById('mapOverlay').style.display = 'flex';
  } catch(err) {
    renderFallbackMap();
  }
}

function renderFallbackMap() {
  const mapEl = document.getElementById('routeMap');
  const overlay = document.getElementById('mapOverlay');
  overlay.style.display = 'none';
  mapEl.innerHTML = `
    <svg width="100%" height="100%" viewBox="0 0 800 500" xmlns="http://www.w3.org/2000/svg" style="background:#1c2030">
      <!-- Colombia outline approximation (decorative) -->
      <defs>
        <filter id="glow"><feGaussianBlur stdDeviation="3" result="blur"/><feMerge><feMergeNode in="blur"/><feMergeNode in="SourceGraphic"/></feMerge></filter>
        <linearGradient id="routeGrad" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" style="stop-color:#3b82f6"/>
          <stop offset="100%" style="stop-color:#8b5cf6"/>
        </linearGradient>
      </defs>
      <!-- Grid lines -->
      ${[...Array(10)].map((_, i) => `<line x1="${i*80}" y1="0" x2="${i*80}" y2="500" stroke="rgba(255,255,255,0.03)" stroke-width="1"/>`).join('')}
      ${[...Array(7)].map((_, i) => `<line x1="0" y1="${i*80}" x2="800" y2="${i*80}" stroke="rgba(255,255,255,0.03)" stroke-width="1"/>`).join('')}

      <!-- Route line (demo) -->
      <polyline id="svgRoute" points="400,80 300,200 250,320 450,400 600,250" 
        fill="none" stroke="url(#routeGrad)" stroke-width="3" stroke-dasharray="8,4"
        filter="url(#glow)" opacity="0"/>

      <!-- City dots -->
      <g id="svgCities" opacity="0">
        <circle cx="400" cy="80"  r="8" fill="#3b82f6" filter="url(#glow)"/>
        <text x="415" y="84" fill="#e8ecf4" font-size="12" font-family="DM Sans">Bogotá</text>

        <circle cx="300" cy="200" r="6" fill="#60a5fa"/>
        <text x="315" y="204" fill="#8b92a8" font-size="11" font-family="DM Sans">Medellín</text>

        <circle cx="250" cy="320" r="6" fill="#60a5fa"/>
        <text x="265" y="324" fill="#8b92a8" font-size="11" font-family="DM Sans">Cali</text>

        <circle cx="450" cy="400" r="6" fill="#60a5fa"/>
        <text x="465" y="404" fill="#8b92a8" font-size="11" font-family="DM Sans">Barranquilla</text>

        <circle cx="600" cy="250" r="6" fill="#60a5fa"/>
        <text x="615" y="254" fill="#8b92a8" font-size="11" font-family="DM Sans">Cartagena</text>
      </g>

      <!-- Overlay message -->
      <g id="svgOverlayMsg">
        <rect x="250" y="190" width="300" height="80" rx="10" fill="rgba(28,32,48,0.95)" stroke="rgba(59,130,246,0.3)" stroke-width="1"/>
        <text x="400" y="222" text-anchor="middle" fill="#e8ecf4" font-size="14" font-family="Syne" font-weight="600">Visualización de Ruta</text>
        <text x="400" y="248" text-anchor="middle" fill="#8b92a8" font-size="12" font-family="DM Sans">Presiona "Calcular Ruta" para ver</text>
      </g>
    </svg>`;
}

function calculateRoute() {
  const stops = [...document.querySelectorAll('#stopsList .stop-item input')]
    .map(i => i.value.trim())
    .filter(Boolean);

  if (!stops.length) {
    toast('Agrega al menos una parada', 'error');
    return;
  }

  const origin = document.getElementById('routeOrigin').value || 'Bogotá';

  // Simulated distances (demo mode)
  const demoDistances = [487, 462, 1020]; // km entre ciudades principales Colombia
  const totalDist = demoDistances.slice(0, stops.length).reduce((a, b) => a + b, 0);
  const vehicle   = document.getElementById('vehicleType').value;
  const speeds    = { camion: 70, furgon: 80, moto: 60 };
  const speed     = speeds[vehicle] || 70;
  const totalTime = totalDist / speed;
  const fuelPer100 = vehicle === 'camion' ? 35 : vehicle === 'furgon' ? 12 : 4;
  const fuel = (totalDist / 100 * fuelPer100).toFixed(0);

  // Update summary
  document.getElementById('routeSummary').style.display = 'block';
  document.getElementById('rsDist').textContent  = `${totalDist.toLocaleString()} km`;
  document.getElementById('rsTime').textContent  = `${Math.floor(totalTime)}h ${Math.round((totalTime % 1)*60)}min`;
  document.getElementById('rsStops').textContent = `${stops.length} paradas`;
  document.getElementById('rsFuel').textContent  = `~${fuel} L`;

  // Animate map
  animateMap(origin, stops);
  renderRouteSteps(origin, stops, demoDistances);
  toast('✔ Ruta calculada y optimizada', 'success');
}

function animateMap(origin, stops) {
  // Try actual mapbox
  if (STATE.map && mapboxgl.accessToken !== 'pk.eyJ1IjoibG9naXRyYWNrLWRlbW8iLCJhIjoiY2x5ZGVtbyJ9.placeholder') {
    addMapboxMarkers(origin, stops);
    return;
  }

  // SVG fallback animation
  const svgRoute   = document.getElementById('svgRoute');
  const svgCities  = document.getElementById('svgCities');
  const svgMsg     = document.getElementById('svgOverlayMsg');

  if (svgRoute) {
    svgRoute.style.transition  = 'opacity 0.5s';
    svgCities.style.transition = 'opacity 0.5s';
    svgRoute.style.opacity  = '1';
    svgCities.style.opacity = '1';
    if (svgMsg) svgMsg.style.display = 'none';

    // Animate dash offset
    const len = svgRoute.getTotalLength?.() || 600;
    svgRoute.style.strokeDasharray  = len;
    svgRoute.style.strokeDashoffset = len;
    svgRoute.style.transition = 'stroke-dashoffset 2s ease, opacity 0.5s';
    setTimeout(() => { svgRoute.style.strokeDashoffset = '0'; }, 100);
  }

  // Hide map overlay
  document.getElementById('mapOverlay').style.display = 'none';
}

function renderRouteSteps(origin, stops, distances) {
  const allPoints = [origin, ...stops];
  const vehicle = document.getElementById('vehicleType').value;
  const speeds  = { camion: 70, furgon: 80, moto: 60 };
  const speed   = speeds[vehicle] || 70;

  let html = '';
  allPoints.forEach((point, i) => {
    const dist = i > 0 ? (distances[i-1] || 300) : null;
    const time = dist ? `${Math.floor(dist/speed)}h ${Math.round(((dist/speed)%1)*60)}min` : null;
    html += `
      <div class="step-item">
        <div class="step-num">${i === 0 ? '⊙' : i}</div>
        <div class="step-info">
          <div class="step-addr">${point}</div>
          <div class="step-meta">${i === 0 ? 'Punto de origen' : `Parada ${i} · ${time} desde anterior`}</div>
        </div>
        ${dist ? `<span class="step-dist">${dist} km</span>` : ''}
      </div>`;
  });

  document.getElementById('routeSteps').innerHTML = html;
}

function addStop() {
  const list = document.getElementById('stopsList');
  const count = list.querySelectorAll('.stop-item').length + 1;
  const div = document.createElement('div');
  div.className = 'stop-item';
  div.innerHTML = `
    <span class="stop-num">${count}</span>
    <input type="text" placeholder="Dirección de entrega">
    <button type="button" class="btn-remove" onclick="removeStop(this)">×</button>`;
  list.appendChild(div);
  updateStopNumbers();
}

function removeStop(btn) {
  btn.parentElement.remove();
  updateStopNumbers();
}

function updateStopNumbers() {
  document.querySelectorAll('#stopsList .stop-num').forEach((n, i) => { n.textContent = i + 1; });
}

function toggleMapView() {
  const mapEl   = document.getElementById('mapContainer');
  const stepsEl = document.getElementById('routeSteps');
  STATE.mapView = STATE.mapView === 'map' ? 'list' : 'map';
  mapEl.style.display   = STATE.mapView === 'map'  ? 'block' : 'none';
  stepsEl.style.display = STATE.mapView === 'list' ? 'flex'  : 'none';
}

// ═══════════════════════════════════════════════
// SUPABASE INTEGRATION
// ═══════════════════════════════════════════════
function connectSupabase() {
  const url = document.getElementById('sbUrl').value.trim();
  const key = document.getElementById('sbKey').value.trim();

  if (!url || !key) { toast('Ingresa URL y Key de Supabase', 'error'); return; }

  try {
    STATE.supabase    = supabase.createClient(url, key);
    STATE.useSupabase = true;
    document.getElementById('connText').textContent = 'Supabase ✓';
    document.querySelector('.conn-dot').classList.add('connected');
    closeModal();
    loadFromSupabase();
    toast('✔ Conectado a Supabase', 'success');
  } catch(err) {
    toast('Error al conectar: ' + err.message, 'error');
  }
}

function skipSupabase() {
  closeModal();
  toast('Modo demo activo — datos locales', 'success');
}

function closeModal() {
  document.getElementById('supabaseModal').style.display = 'none';
}

// ── Supabase CRUD ─────────────────────────────
async function saveCitaToSupabase(cita) {
  if (!STATE.supabase) return;
  const { error } = await STATE.supabase.from('citas').insert([{
    empresa:  cita.empresa,
    tipo:     cita.tipo,
    fecha:    cita.fecha,
    hora:     cita.hora,
    muelle:   cita.muelle,
    duracion: cita.duracion,
    estado:   cita.estado,
    notas:    cita.notas,
  }]);
  if (error) console.error('Supabase error:', error.message);
}

async function loadFromSupabase() {
  if (!STATE.supabase) return;
  const { data, error } = await STATE.supabase
    .from('citas')
    .select('*')
    .order('fecha', { ascending: true });

  if (error) { console.error(error); return; }
  if (data?.length) {
    STATE.citas = data;
    renderCitas();
    buildWeekStrip();
    renderCitasMini();
    toast(`📥 ${data.length} citas cargadas desde Supabase`, 'success');
  }
}

async function saveCubicajeToSupabase() {
  if (!STATE.supabase) return;
  const cType = document.getElementById('containerType').value;
  let totalVol = 0, totalWeight = 0;
  STATE.products.forEach(p => {
    totalVol    += (p.l * p.w * p.h / 1e6) * p.qty;
    totalWeight += p.weight * p.qty;
  });

  const { error } = await STATE.supabase.from('cubicaje').insert([{
    container_type:   cType,
    total_volume_m3:  totalVol,
    total_weight_kg:  totalWeight,
    products_json:    JSON.stringify(STATE.products),
    created_at:       new Date().toISOString(),
  }]);
  if (error) console.error('Supabase error:', error.message);
  else toast('✔ Cubicaje guardado en Supabase', 'success');
}

// ═══════════════════════════════════════════════
// LOCAL STORAGE FALLBACK
// ═══════════════════════════════════════════════
function saveToStorage() {
  try {
    localStorage.setItem('lt_products', JSON.stringify(STATE.products));
    localStorage.setItem('lt_citas',    JSON.stringify(STATE.citas));
  } catch(e) {}
}

function loadFromStorage() {
  try {
    const p = localStorage.getItem('lt_products');
    const c = localStorage.getItem('lt_citas');
    if (p) STATE.products = JSON.parse(p);
    if (c) STATE.citas    = JSON.parse(c);
  } catch(e) {}
}

// ═══════════════════════════════════════════════
// TOAST NOTIFICATIONS
// ═══════════════════════════════════════════════
function toast(msg, type = 'success') {
  const el = document.createElement('div');
  el.className = `toast ${type}`;
  el.textContent = msg;
  document.getElementById('toastContainer').appendChild(el);
  setTimeout(() => { el.style.opacity = '0'; el.style.transition = 'opacity 0.3s'; }, 3000);
  setTimeout(() => el.remove(), 3400);
}

// ═══════════════════════════════════════════════
// UTILITIES
// ═══════════════════════════════════════════════
function capitalize(s) { return s.charAt(0).toUpperCase() + s.slice(1); }

function formatDate(str) {
  if (!str) return '';
  const d = new Date(str + 'T00:00:00');
  return d.toLocaleDateString('es-CO', { day: 'numeric', month: 'short' });
}

function tipoLabel(tipo) {
  return { carga: '🟢 Carga', descarga: '🔴 Descarga', mixto: '🟡 Mixto' }[tipo] || tipo;
}

// Auto-set today's date on cita form
document.addEventListener('DOMContentLoaded', () => {
  const fechaInput = document.getElementById('citaFecha');
  if (fechaInput) fechaInput.value = new Date().toISOString().split('T')[0];
});
