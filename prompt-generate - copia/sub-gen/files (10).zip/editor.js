// ════════════════════════════════════════════════════════
// editor.js — Editor de subtítulos con estilos visuales
// ════════════════════════════════════════════════════════

const SubtitleEditor = (() => {

  // ── Estado ────────────────────────────────────────────
  let _entries      = [];   // [{ index, start, end, startSec, endSec, text }]
  let _activePreset = 'mrbeast';
  let _config       = {};
  let _videoEl      = null;
  let _overlayEl    = null;
  let _onSRTChange  = null;
  let _lastSubIdx   = -1;

  // ══════════════════════════════════════════════════════
  // PRESETS DE ESTILOS
  // ══════════════════════════════════════════════════════
  const PRESETS = {
    mrbeast: {
      label:         'MrBeast',
      emoji:         '⚡',
      fontFamily:    "'Bangers', Impact, 'Arial Black', sans-serif",
      fontSize:      58,
      color:         '#FFD700',
      stroke:        '#000000',
      strokeW:       5,
      shadow:        '4px 4px 0 #000, -2px -2px 0 #000, 2px -2px 0 #000, -2px 2px 0 #000',
      bgColor:       'transparent',
      position:      'bottom',
      animation:     'pop',
      uppercase:     true,
      letterSpacing: 2,
      lineHeight:    1.0,
      maxWidth:      '85%',
      charsPerLine:  0, // 0 = automatic
    },
    tiktok: {
      label:         'TikTok',
      emoji:         '🎵',
      fontFamily:    "'Poppins', 'Proxima Nova', Arial, sans-serif",
      fontSize:      28,
      color:         '#FFFFFF',
      stroke:        '#000000',
      strokeW:       4,
      shadow:        '2px 2px 4px rgba(0,0,0,0.8)',
      bgColor:       'rgba(0,0,0,0.4)',
      position:      'center',
      animation:     'fade',
      uppercase:     false,
      letterSpacing: 0.5,
      lineHeight:    1.3,
      maxWidth:      '90%',
      charsPerLine:  25,
    },
    reels: {
      label:         'Instagram Reels',
      emoji:         '📸',
      fontFamily:    "'Poppins', 'Proxima Nova', Arial, sans-serif",
      fontSize:      26,
      color:         '#FFFFFF',
      stroke:        '#000000',
      strokeW:       3,
      shadow:        '1px 1px 3px rgba(0,0,0,0.7)',
      bgColor:       'rgba(0,0,0,0.5)',
      position:      'center',
      animation:     'fade',
      uppercase:     false,
      letterSpacing: 0.3,
      lineHeight:    1.4,
      maxWidth:      '85%',
      charsPerLine:  20,
    },
    netflix: {
      label:         'Netflix',
      emoji:         '🎬',
      fontFamily:    "'Syne', Arial, sans-serif",
      fontSize:      26,
      color:         '#FFFFFF',
      stroke:        '#000',
      strokeW:       1,
      shadow:        '1px 1px 5px rgba(0,0,0,0.95), 0 0 20px rgba(0,0,0,0.7)',
      bgColor:       'rgba(0,0,0,0.78)',
      position:      'bottom',
      animation:     'fade',
      uppercase:     false,
      letterSpacing: 0.3,
      lineHeight:    1.5,
      maxWidth:      '75%',
    },
    neon: {
      label:         'Neon',
      emoji:         '💫',
      fontFamily:    "'DM Mono', 'Courier New', monospace",
      fontSize:      28,
      color:         '#00FFFF',
      stroke:        'transparent',
      strokeW:       0,
      shadow:        '0 0 8px #00FFFF, 0 0 20px #00FFFF, 0 0 40px #00CCCC, 0 0 60px #009999',
      bgColor:       'transparent',
      position:      'bottom',
      animation:     'fade',
      uppercase:     false,
      letterSpacing: 3,
      lineHeight:    1.4,
      maxWidth:      '80%',
    },
    fire: {
      label:         'Fire',
      emoji:         '🔥',
      fontFamily:    "'Bangers', Impact, 'Arial Black', sans-serif",
      fontSize:      52,
      color:         '#FF6B00',
      stroke:        '#7A0000',
      strokeW:       4,
      shadow:        '0 0 20px #FF4500, 0 0 40px #FF2200, 3px 3px 0 #000',
      bgColor:       'transparent',
      position:      'center',
      animation:     'slide',
      uppercase:     true,
      letterSpacing: 1,
      lineHeight:    1.0,
      maxWidth:      '80%',
    },
    minimal: {
      label:         'Minimal',
      emoji:         '✦',
      fontFamily:    "'Syne', Arial, sans-serif",
      fontSize:      22,
      color:         '#FFFFFF',
      stroke:        'transparent',
      strokeW:       0,
      shadow:        '0 2px 8px rgba(0,0,0,0.6)',
      bgColor:       'transparent',
      position:      'bottom',
      animation:     'fade',
      uppercase:     false,
      letterSpacing: 0,
      lineHeight:    1.6,
      maxWidth:      '70%',
    },
  };

  // ══════════════════════════════════════════════════════
  // INIT (punto de entrada público)
  // ══════════════════════════════════════════════════════
  function init(entries, videoEl, overlayEl, onSRTChange) {
    _entries     = entries.map((e, i) => ({ ...e, _uid: i }));
    _videoEl     = videoEl;
    _overlayEl   = overlayEl;
    _onSRTChange = onSRTChange;
    _lastSubIdx  = -1;

    _buildEditorUI();
    _applyPreset('mrbeast');
    _startVideoSync();
  }

  // ══════════════════════════════════════════════════════
  // CONSTRUCCIÓN DE LA UI
  // ══════════════════════════════════════════════════════
  function _buildEditorUI() {
    const section = document.getElementById('editor-section');
    if (!section) return;
    section.innerHTML = '';
    section.classList.remove('hidden');

    // ── Título de sección ────────────────────────────
    const title = document.createElement('div');
    title.className = 'editor-section-title';
    title.innerHTML = '<span>🎨 Editor de Estilo</span>';
    section.appendChild(title);

    // ── Preset pills ─────────────────────────────────
    const presetsWrap = document.createElement('div');
    presetsWrap.className = 'presets-wrap';

    Object.entries(PRESETS).forEach(([key, preset]) => {
      const btn = document.createElement('button');
      btn.className = `preset-pill ${key === _activePreset ? 'active' : ''}`;
      btn.dataset.preset = key;
      btn.innerHTML = `<span>${preset.emoji}</span><span>${preset.label}</span>`;
      btn.addEventListener('click', () => _applyPreset(key));
      presetsWrap.appendChild(btn);
    });
    section.appendChild(presetsWrap);

    // ── Controles finos ──────────────────────────────
    const controls = document.createElement('div');
    controls.className = 'fine-controls';
    controls.innerHTML = `
      <div class="fine-ctrl-group">
        <label>Tamaño</label>
        <div class="range-row">
          <input type="range" id="ctrl-size" min="8" max="80" value="58" />
          <span id="ctrl-size-val" class="range-val">58px</span>
        </div>
      </div>
      <div class="fine-ctrl-group">
        <label>Color texto</label>
        <input type="color" id="ctrl-color" value="#FFD700" class="color-picker" />
      </div>
      <div class="fine-ctrl-group">
        <label>Posición</label>
        <select id="ctrl-position" class="mini-select">
          <option value="bottom">Abajo</option>
          <option value="center">Centro</option>
          <option value="top">Arriba</option>
        </select>
      </div>
      <div class="fine-ctrl-group">
        <label>Ajustar Y</label>
        <input type="range" id="ctrl-yoffset" class="mini-range" min="-100" max="100" value="0" style="width:80px" />
        <span id="ctrl-yoffset-val" class="mini-val">0</span>
      </div>
      <div class="fine-ctrl-group">
        <label>Caracteres/línea</label>
        <select id="ctrl-charsperline" class="mini-select">
          <option value="0">Automático</option>
          <option value="15">15</option>
          <option value="20">20</option>
          <option value="25">25</option>
          <option value="30">30</option>
          <option value="35">35</option>
          <option value="40">40</option>
        </select>
      </div>
      <div class="fine-ctrl-group">
        <label>Animación</label>
        <select id="ctrl-animation" class="mini-select">
          <option value="pop">Pop ⚡</option>
          <option value="fade">Fade ✦</option>
          <option value="slide">Slide ↑</option>
          <option value="bounce">Bounce 〜</option>
          <option value="none">Sin animación</option>
        </select>
      </div>
      <div class="fine-ctrl-group">
        <label>MAYÚSCULAS</label>
        <label class="toggle">
          <input type="checkbox" id="ctrl-upper" checked />
          <span class="toggle-track"><span class="toggle-thumb"></span></span>
        </label>
      </div>
    `;
    section.appendChild(controls);
    _wireControls();

    // ── Lista editora de subtítulos ──────────────────
    const listHeader = document.createElement('div');
    listHeader.className = 'entries-header';
    listHeader.innerHTML = `
      <span>✏️ Editar subtítulos <span class="entry-cnt">${_entries.length} entradas</span></span>
      <button id="btn-add-entry" class="btn-add-entry">+ Añadir</button>
    `;
    section.appendChild(listHeader);

    const list = document.createElement('div');
    list.className = 'entries-list';
    list.id = 'entries-list';
    _entries.forEach(entry => list.appendChild(_buildEntryRow(entry)));
    section.appendChild(list);

    // Botón añadir entrada
    document.getElementById('btn-add-entry').addEventListener('click', () => _addEntry());
  }

  function _buildEntryRow(entry) {
    const row = document.createElement('div');
    row.className = 'entry-row';
    row.id = `erow-${entry._uid}`;

    const startFormatted = _secToMMSS(entry.startSec);
    const endFormatted   = _secToMMSS(entry.endSec);

    row.innerHTML = `
      <span class="entry-idx">${entry.index}</span>
      <button class="entry-time-btn" title="Ir a este momento">${startFormatted}</button>
      <input class="entry-input" type="text" value="${_escHtml(entry.text)}" placeholder="Texto..." />
      <button class="entry-del-btn" title="Eliminar">✕</button>
    `;

    // Click en tiempo → seek
    row.querySelector('.entry-time-btn').addEventListener('click', () => {
      if (_videoEl && !isNaN(entry.startSec)) {
        _videoEl.currentTime = entry.startSec + 0.05;
        _videoEl.play();
      }
    });

    // Edit text
    const input = row.querySelector('.entry-input');
    input.addEventListener('input', () => {
      entry.text = input.value;
      _notifyChange();
    });

    // Delete
    row.querySelector('.entry-del-btn').addEventListener('click', () => {
      _entries = _entries.filter(e => e._uid !== entry._uid);
      row.remove();
      _updateEntryCnt();
      _notifyChange();
    });

    return row;
  }

  function _addEntry() {
    const lastEntry = _entries[_entries.length - 1];
    const startSec  = lastEntry ? lastEntry.endSec + 0.5 : 0;
    const endSec    = startSec + 3;
    const uid       = Date.now();
    const entry     = {
      _uid:     uid,
      index:    _entries.length + 1,
      start:    SRT.secondsToTimestamp(startSec),
      end:      SRT.secondsToTimestamp(endSec),
      startSec, endSec,
      text:     'Nuevo subtítulo'
    };
    _entries.push(entry);
    document.getElementById('entries-list')?.appendChild(_buildEntryRow(entry));
    _updateEntryCnt();
    _notifyChange();
  }

  function _updateEntryCnt() {
    const el = document.querySelector('.entry-cnt');
    if (el) el.textContent = `${_entries.length} entradas`;
  }

  // ── Controles finos ──────────────────────────────────
  function _wireControls() {
    const get = id => document.getElementById(id);

    get('ctrl-size')?.addEventListener('input', function () {
      const val = parseInt(this.value);
      const display = get('ctrl-size-val');
      if (display) display.textContent = val + 'px';
      const currentStrokeW = _config.strokeW || 0;
      const strokeW = currentStrokeW > 0 ? Math.max(1, Math.round(val * 0.12)) : 0;
      _override({ fontSize: val, strokeW: strokeW });
    });

    get('ctrl-color')?.addEventListener('input', function () {
      _override({ color: this.value });
    });

    get('ctrl-position')?.addEventListener('change', function () {
      _override({ position: this.value });
    });

    get('ctrl-yoffset')?.addEventListener('input', function () {
      const val = parseInt(this.value) || 0;
      document.getElementById('ctrl-yoffset-val').textContent = val;
      _override({ yOffset: val });
    });

    get('ctrl-charsperline')?.addEventListener('change', function () {
      _override({ charsPerLine: parseInt(this.value) || 0 });
    });

    get('ctrl-animation')?.addEventListener('change', function () {
      _override({ animation: this.value });
    });

    get('ctrl-upper')?.addEventListener('change', function () {
      _override({ uppercase: this.checked });
    });
  }

  function _syncControls(cfg) {
    const get = id => document.getElementById(id);
    const sizeEl = get('ctrl-size');
    const sizeValEl = get('ctrl-size-val');
    if (sizeEl)    { sizeEl.value = cfg.fontSize; }
    if (sizeValEl) { sizeValEl.textContent = cfg.fontSize + 'px'; }
    const colorEl = get('ctrl-color');
    if (colorEl) colorEl.value = cfg.color || '#ffffff';
    const posEl = get('ctrl-position');
    if (posEl) posEl.value = cfg.position || 'bottom';
    const yOffsetEl = get('ctrl-yoffset');
    if (yOffsetEl) {
      yOffsetEl.value = cfg.yOffset || 0;
      const valEl = get('ctrl-yoffset-val');
      if (valEl) valEl.textContent = cfg.yOffset || 0;
    }
    const charsEl = get('ctrl-charsperline');
    if (charsEl) charsEl.value = cfg.charsPerLine || 0;
    const animEl = get('ctrl-animation');
    if (animEl) animEl.value = cfg.animation || 'pop';
    const upperEl = get('ctrl-upper');
    if (upperEl) upperEl.checked = !!cfg.uppercase;
  }

  // ══════════════════════════════════════════════════════
  // APLICAR ESTILOS
  // ══════════════════════════════════════════════════════
  function _applyPreset(key) {
    _activePreset = key;
    _config = { ...PRESETS[key] };

    document.querySelectorAll('.preset-pill').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.preset === key);
    });

    _syncControls(_config);
    _applyToOverlay(_config);
  }

  function _override(overrides) {
    _config = { ..._config, ...overrides };
    _applyToOverlay(_config);
  }

  function _applyToOverlay(cfg) {
    if (!_overlayEl) return;

    const hasBg   = cfg.bgColor && cfg.bgColor !== 'transparent';
    const textStk = cfg.strokeW > 0 ? `${cfg.strokeW}px ${cfg.stroke}` : '';

    // Aplicar estilos base al overlay (sin posición, eso va aparte)
    _overlayEl.style.cssText = `
      position: absolute;
      left: 50%;
      font-family: ${cfg.fontFamily};
      font-size: ${cfg.fontSize}px;
      letter-spacing: ${cfg.letterSpacing || 0}px;
      line-height: ${cfg.lineHeight || 1.2};
      text-transform: ${cfg.uppercase ? 'uppercase' : 'none'};
      text-align: center;
      max-width: ${cfg.maxWidth || '80%'};
      pointer-events: none;
      z-index: 10;
      transition: none;
      padding: 0;
      background: transparent;
    `;

    // ── POSICIÓN: usar setProperty con 'important' para vencer el CSS ──
    // Esto es necesario porque el CSS del editor usa !important en estos valores
    const pos = {
      bottom: { bottom: '7%',  top: 'auto',  transform: 'translateX(-50%)' },
      center: { bottom: '45%', top: 'auto',  transform: 'translate(-50%, 50%)' },
      top:    { bottom: 'auto', top: '7%',   transform: 'translateX(-50%)' },
    }[cfg.position || 'bottom'];

    _overlayEl.style.setProperty('bottom',    pos.bottom,    'important');
    _overlayEl.style.setProperty('top',       pos.top,       'important');
    _overlayEl.style.setProperty('transform', pos.transform, 'important');

    // Si hay texto activo, re-render para aplicar los nuevos estilos al span
    if (_overlayEl.children.length > 0) {
      const currentText = _overlayEl.querySelector('.subtitle-text')?.textContent || '';
      if (currentText) _renderSubtitleText(currentText, cfg.animation);
    }
  }

  // ══════════════════════════════════════════════════════
  // SYNC CON VIDEO
  // ══════════════════════════════════════════════════════
  function _startVideoSync() {
    if (!_videoEl || !_overlayEl) return;

    _videoEl.addEventListener('timeupdate', () => {
      const t      = _videoEl.currentTime;
      const active = _entries.find(e => t >= e.startSec && t <= e.endSec);
      const curIdx = active ? active._uid : -1;

      if (curIdx !== _lastSubIdx) {
        _lastSubIdx = curIdx;

        // Highlight entry row
        document.querySelectorAll('.entry-row').forEach(r => r.classList.remove('entry-active'));
        if (active) {
          const row = document.getElementById(`erow-${active._uid}`);
          if (row) {
            row.classList.add('entry-active');
            row.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
          }
        }

        // Actualizar overlay
        if (active) {
          const text = _config.uppercase
            ? active.text.toUpperCase()
            : active.text;
          _renderSubtitleText(text, _config.animation);
        } else {
          _overlayEl.innerHTML = '';
        }
      }
    });
  }

  function _renderSubtitleText(text, animation = 'pop') {
    if (!_overlayEl) return;
    _overlayEl.innerHTML = '';
    void _overlayEl.offsetWidth; // force reflow para reiniciar animación

    const span = document.createElement('span');
    span.className = `subtitle-text sub-anim-${animation}`;
    span.textContent = text;

    // ── Bug fix: aplicar estilos visuales DIRECTAMENTE al span ──
    // .subtitle-text en CSS tiene color:#fff y text-shadow propios
    // que taparían lo que se pone en el div padre (no se hereda bien)
    const cfg = _config;
    const hasBg   = cfg.bgColor && cfg.bgColor !== 'transparent';
    const textStk = cfg.strokeW > 0 ? `${cfg.strokeW}px ${cfg.stroke}` : 'none';

    span.style.color             = cfg.color || '#ffffff';
    span.style.textShadow        = cfg.shadow || 'none';
    span.style.webkitTextStroke  = textStk;
    span.style.background        = hasBg ? cfg.bgColor : 'transparent';
    span.style.padding           = hasBg ? '6px 18px' : '0';
    span.style.borderRadius      = hasBg ? '6px' : '0';
    span.style.fontFamily        = cfg.fontFamily;
    span.style.fontSize          = cfg.fontSize + 'px';
    span.style.letterSpacing     = (cfg.letterSpacing || 0) + 'px';
    span.style.lineHeight        = cfg.lineHeight || 1.2;
    span.style.textTransform     = cfg.uppercase ? 'uppercase' : 'none';
    // Fix: centrado y control de saltos de línea directamente en el span
    span.style.textAlign         = 'center';
    span.style.display           = 'block';
    span.style.maxWidth          = cfg.maxWidth || '80%';
    span.style.margin            = '0 auto';
    span.style.wordBreak         = 'break-word';
    span.style.overflowWrap      = 'break-word';

    _overlayEl.appendChild(span);
  }

  // ══════════════════════════════════════════════════════
  // EXPORT SRT
  // ══════════════════════════════════════════════════════
  function exportSRT() {
    return _entries
      .map((e, i) => `${i + 1}\n${e.start} --> ${e.end}\n${e.text}`)
      .join('\n\n') + '\n';
  }

  // ══════════════════════════════════════════════════════
  // HELPERS
  // ══════════════════════════════════════════════════════
  function _notifyChange() {
    if (_onSRTChange) _onSRTChange(exportSRT());
  }

  function _secToMMSS(sec) {
    if (!sec && sec !== 0) return '0:00';
    const m = Math.floor(sec / 60);
    const s = Math.floor(sec % 60).toString().padStart(2, '0');
    return `${m}:${s}`;
  }

  function _escHtml(str) {
    return (str || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  // ── API pública ──────────────────────────────────────
  function getBurnConfig() {
    return {
      fontSize: _config.fontSize || 28,
      color: _config.color || '#FFFFFF',
      stroke: _config.stroke || '#000000',
      strokeW: _config.strokeW || 3,
      position: _config.position || 'center',
      bgColor: _config.bgColor || 'transparent',
      fontFamily: _config.fontFamily || 'Arial',
      uppercase: _config.uppercase || false,
      charsPerLine: _config.charsPerLine || 20,
      yOffset: _config.yOffset || 0,
      xOffset: _config.xOffset || 0,
    };
  }

  return { init, exportSRT, get config() { return _config; }, getBurnConfig };

})();

window.SubtitleEditor = SubtitleEditor;
console.log('[editor.js] ✓ Editor de subtítulos cargado.');
