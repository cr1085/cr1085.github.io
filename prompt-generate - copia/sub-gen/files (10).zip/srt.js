// ════════════════════════════════════════════
// srt.js — Generación y manejo de subtítulos SRT
// ════════════════════════════════════════════

const SRT = {
  /**
   * Convierte segundos a formato timestamp SRT
   * @param {number} seconds - Tiempo en segundos (puede ser decimal)
   * @returns {string} - Formato HH:MM:SS,mmm
   */
  secondsToTimestamp(seconds) {
    const ms   = Math.round((seconds % 1) * 1000);
    const secs = Math.floor(seconds) % 60;
    const mins = Math.floor(seconds / 60) % 60;
    const hrs  = Math.floor(seconds / 3600);

    return [
      String(hrs).padStart(2, '0'),
      String(mins).padStart(2, '0'),
      String(secs).padStart(2, '0')
    ].join(':') + ',' + String(ms).padStart(3, '0');
  },

  /**
   * Convierte timestamp SRT a segundos
   * @param {string} timestamp - Formato HH:MM:SS,mmm
   * @returns {number}
   */
  timestampToSeconds(timestamp) {
    const [time, ms] = timestamp.split(',');
    const [h, m, s]  = time.split(':').map(Number);
    return h * 3600 + m * 60 + s + Number(ms) / 1000;
  },

  /**
   * Genera contenido SRT desde array de segmentos Whisper
   * @param {Array} segments - [{ start, end, text }]
   * @returns {string} - Contenido del archivo .srt
   */
  fromSegments(segments) {
    if (!segments || segments.length === 0) {
      return '';
    }

    return segments
      .map((seg, i) => {
        const start = this.secondsToTimestamp(seg.start);
        const end   = this.secondsToTimestamp(seg.end);
        const text  = seg.text.trim();

        return `${i + 1}\n${start} --> ${end}\n${text}`;
      })
      .join('\n\n') + '\n';
  },

  /**
   * Parsea contenido SRT a array de objetos
   * @param {string} srtContent
   * @returns {Array} - [{ index, start, end, startSec, endSec, text }]
   */
  parse(srtContent) {
    if (!srtContent) return [];

    const blocks = srtContent.trim().split(/\n\n+/);

    return blocks
      .map(block => {
        const lines = block.trim().split('\n');
        if (lines.length < 3) return null;

        const index = parseInt(lines[0]);
        const times = lines[1].split(' --> ');
        if (times.length !== 2) return null;

        const start    = times[0].trim();
        const end      = times[1].trim();
        const text     = lines.slice(2).join('\n');
        const startSec = this.timestampToSeconds(start);
        const endSec   = this.timestampToSeconds(end);

        return { index, start, end, startSec, endSec, text };
      })
      .filter(Boolean);
  },

  /**
   * Genera el SRT como demostración (cuando Whisper no está disponible)
   * Crea segmentos simulados para testing
   * @param {number} durationSeconds - Duración del video
   * @param {string} language - Idioma
   * @returns {string}
   */
  generateDemo(durationSeconds = 60, language = 'es') {
    const demoTexts = {
      es: [
        'Bienvenidos a este video de demostración.',
        'SubGen genera subtítulos automáticos con inteligencia artificial.',
        'El audio se procesa con el modelo Whisper de OpenAI.',
        'Los subtítulos se generan en formato SRT estándar.',
        'Puedes descargar el archivo y usarlo en cualquier editor.',
        'El proceso tarda unos segundos dependiendo del video.',
        'Soportamos múltiples idiomas automáticamente.',
        'Gracias por usar SubGen. ¡Hasta pronto!'
      ],
      en: [
        'Welcome to this demonstration video.',
        'SubGen generates automatic subtitles using AI.',
        'Audio is processed with OpenAI\'s Whisper model.',
        'Subtitles are generated in standard SRT format.',
        'Download the file and use it in any video editor.',
        'Processing takes a few seconds depending on video length.',
        'We support multiple languages automatically.',
        'Thanks for using SubGen. See you soon!'
      ]
    };

    const texts = demoTexts[language] || demoTexts.en;
    const segDuration = durationSeconds / texts.length;

    const segments = texts.map((text, i) => ({
      start: i * segDuration + 0.1,
      end:   (i + 1) * segDuration - 0.1,
      text
    }));

    return this.fromSegments(segments);
  },

  /**
   * Descarga el contenido SRT como archivo
   * @param {string} content - Contenido del SRT
   * @param {string} filename - Nombre base del archivo (sin extensión)
   */
  download(content, filename = 'subtitulos') {
    // Asegurar que el nombre siempre tenga extensión .srt
    const safeName = (filename || 'subtitulos')
      .replace(/\.[^.]+$/, '')   // quitar extensión previa si tiene
      .replace(/[^a-zA-Z0-9_\-. áéíóúñÁÉÍÓÚÑ]/g, '_') // limpiar caracteres raros
      || 'subtitulos';

    // application/octet-stream fuerza la descarga y evita que el
    // navegador o Windows cambie/elimine la extensión .srt
    const blob = new Blob(['\uFEFF' + content], {
      type: 'application/octet-stream'
    });

    const url = URL.createObjectURL(blob);
    const a   = document.createElement('a');
    a.href     = url;
    a.download = `${safeName}.srt`;
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();

    // Limpiar después de un momento
    setTimeout(() => {
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }, 200);
  },

  /**
   * Obtener el texto del subtítulo activo en un momento dado
   * @param {Array} parsed - Array de subtítulos parseados
   * @param {number} currentTime - Tiempo actual del video en segundos
   * @returns {string|null}
   */
  getActiveSubtitle(parsed, currentTime) {
    const active = parsed.find(
      sub => currentTime >= sub.startSec && currentTime <= sub.endSec
    );
    return active ? active.text : null;
  }
};

window.SRT = SRT;


SRT.toVTT = function(srt){

  const vtt = "WEBVTT\n\n" +
  srt.replace(/,/g,".")

  return vtt
}